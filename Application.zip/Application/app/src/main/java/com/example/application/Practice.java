package com.example.application;

import android.text.format.Time;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class Practice {
    public static void main(String[] args) {

        int[] nums = {1,2,4,6,8,9,10,15,67,83,24,55};
        Random rd = new Random();
        int randomNum = rd.nextInt(nums.length-1);
        System.out.println(nums[randomNum]);

    }
    public static void printFibonacciSeries(int count) {
        int a = 0;
        int b = 1;
        int c = 1;
        for (int i = 1; i <= count; i++) {
            System.out.print(a + ", ");
            a = b;
            b = c;
            c = a + b;
        }
    }
    public static boolean stringContainsVowels(String input) {

        return input.toLowerCase().matches(".*[aeiou].*");

    }
    public static boolean isPrime(int n) {
        if (n == 0 || n == 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }
    static void randomNumber(int[] arr){
        Random rd = new Random();
        for (int x:arr
             ) {
            x = rd.nextInt();
            System.out.println(arr[x]);
        }

    }


}
