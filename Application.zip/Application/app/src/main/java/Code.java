public class Code {
    public static void main(String[] args) {
        String name = "Hrithik";
        String forward = "";
        String reverse = "";
        int half = (int) name.length()/2;
        for(int i = half+1;i<name.length();i++){
            reverse = reverse + name.charAt(i);

        }
        for(int i = 0;i<=half;i++){
            forward = forward + name.charAt(i);

        }
        System.out.println(reverse+forward);
    }
}
